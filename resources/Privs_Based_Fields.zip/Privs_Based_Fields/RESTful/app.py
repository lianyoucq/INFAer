from flask import Flask
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)

@app.route("/")
def index():
    return "Privileges demo server"

privs = {10110140: { 'CUSTOMER_ID': 10110140,
		     'Level': 1, 
		     'Fields': [ 'CUSTOMER_REGION',
                     'CUSTOMER_TIER',
                     'CUSTOMER_NAME',
                     'COMPANY_NAME']
		   },
         10111996: { 'CUSTOMER_ID': 10111996,
		     'Level': 2,
		     'Fields': ['COMPANY_NAME',
                    'COMPANY_ADDRESS']
		   },
         10112047: { 'CUSTOMER_ID': 10112047,
		     'Level': 3,
		     'Fields': ['COMPANY_NAME',
                    'COMPANY_ADDRESS']
		   }
};

class Privileges(Resource):
    def get(self, cid):
        existing = 1
        if cid in privs.keys():
            existing=0
            fields = privs.get(cid)
        else:
            fields="Nothing"
            existing = 1
        return {
                'Existing': existing,
                'Privs': fields
                }


api.add_resource(Privileges, '/p/<int:cid>')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5055)
